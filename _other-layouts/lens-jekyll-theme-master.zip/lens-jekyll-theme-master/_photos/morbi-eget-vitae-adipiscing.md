---
title: Morbi eget vitae adipiscing
image: assets/images/fulls/09.jpg
thumbnail: assets/images/thumbs/09.jpg
caption: In quis vulputate dui. Maecenas metus elit, dictum praesent lacinia lacus.
---
